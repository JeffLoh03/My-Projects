public class DoubleSecondDigit {
    public static void DoubleSecondDigit (String[] args){
        long creditCardNumber = 1234567;
        long secondDigits = 0;
        int position = 0;
        int multiplier = 1;

        while (creditCardNumber > 0) {
            // Get the last digit
            int digit = (int) (creditCardNumber % 10);
            creditCardNumber /= 10;

            // Check if this is a second position (1-based index)
            if (position % 2 == 1) {
                secondDigits += digit * multiplier;
                multiplier *= 10; // Move to the next decimal place in the result
            }

            position++;
        }

        // Output the result
        System.out.println("Every second digit: " + secondDigits);
    }
}
    

